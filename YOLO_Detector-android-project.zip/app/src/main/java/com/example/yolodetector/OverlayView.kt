package com.example.yolodetector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class OverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var results: List<Recognition> = emptyList()

    private val boxPaint = Paint().apply {
        color = Color.parseColor("#38BDF8")
        style = Paint.Style.STROKE
        strokeWidth = 6f
        isAntiAlias = true
    }

    private val textBackgroundPaint = Paint().apply {
        color = Color.parseColor("#E60F172A")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 38f
        isAntiAlias = true
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    fun setResults(newResults: List<Recognition>) {
        this.results = newResults
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        for (item in results) {
            val box = item.location ?: continue

            // Scale to view dimensions
            val scaleX = width.toFloat() / maxOf(1f, right.toFloat())
            val scaleY = height.toFloat() / maxOf(1f, bottom.toFloat())

            val rect = RectF(
                box.left * scaleX,
                box.top * scaleY,
                box.right * scaleX,
                box.bottom * scaleY
            )

            // Draw bounding rect
            canvas.drawRoundRect(rect, 8f, 8f, boxPaint)

            // Draw text badge
            val labelText = "${item.title} ${String.format("%.1f%%", item.confidence * 100)}"
            val textWidth = textPaint.measureText(labelText)
            val textHeight = 44f

            val badgeRect = RectF(
                rect.left,
                maxOf(0f, rect.top - textHeight - 12f),
                rect.left + textWidth + 24f,
                rect.top
            )

            canvas.drawRoundRect(badgeRect, 6f, 6f, textBackgroundPaint)
            canvas.drawText(labelText, badgeRect.left + 12f, badgeRect.bottom - 12f, textPaint)
        }
    }
}
