package com.example.yolodetector

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.os.SystemClock
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.BufferedReader
import java.io.InputStreamReader

data class Recognition(
    val id: Int,
    val title: String,
    val confidence: Float,
    val location: RectF
)

class TFLiteHelper(
    private val context: Context,
    private val modelFileName: String = "model.tflite",
    private val labelFileName: String = "labels.txt",
    private val confidenceThreshold: Float = 0.45f,
    private val iouThreshold: Float = 0.5f
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null
    private val labels = mutableListOf<String>()

    private val inputWidth = 640
    private val inputHeight = 640

    init {
        loadLabels()
        setupInterpreter()
    }

    private fun loadLabels() {
        try {
            val inputStream = context.assets.open(labelFileName)
            val reader = BufferedReader(InputStreamReader(inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                line?.let { if (it.isNotBlank()) labels.add(it.trim()) }
            }
            reader.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupInterpreter() {
        val options = Interpreter.Options()
        options.setNumThreads(4)

        val compatList = CompatibilityList()
        if (compatList.isDelegateSupportedOnThisDevice) {
            val delegateOptions = compatList.bestOptionsForThisDevice
            gpuDelegate = GpuDelegate(delegateOptions)
            options.addDelegate(gpuDelegate)
        }

        val modelBuffer = FileUtil.loadMappedFile(context, modelFileName)
        interpreter = Interpreter(modelBuffer, options)
    }

    fun detect(bitmap: Bitmap): Pair<List<Recognition>, Long> {
        val startTime = SystemClock.uptimeMillis()

        // 1. Preprocess Image
        val imageProcessor = ImageProcessor.Builder()
            .add(ResizeOp(inputHeight, inputWidth, ResizeOp.ResizeMethod.BILINEAR))
            .add(NormalizeOp(0.0f, 255.0f))
            .build()

        var tensorImage = TensorImage(DataType.FLOAT32)
        tensorImage.load(bitmap)
        tensorImage = imageProcessor.process(tensorImage)

        // 2. Prepare Output Buffer (YOLO shape: 1, 84, 8400 or transposed 1, 8400, 84)
        val outputTensor = interpreter?.getOutputTensor(0)
        val outputShape = outputTensor?.shape() ?: intArrayOf(1, 84, 8400)
        val outputBuffer = TensorBuffer.createFixedSize(outputShape, DataType.FLOAT32)

        // 3. Run Inference
        interpreter?.run(tensorImage.buffer, outputBuffer.buffer.rewind())
        val inferenceTime = SystemClock.uptimeMillis() - startTime

        // 4. Decode YOLO Output
        val rawOutput = outputBuffer.floatArray
        val recognitions = parseYoloOutput(rawOutput, outputShape, bitmap.width, bitmap.height)

        return Pair(recognitions, inferenceTime)
    }

    private fun parseYoloOutput(
        output: FloatArray,
        shape: IntArray,
        imageWidth: Int,
        imageHeight: Int
    ): List<Recognition> {
        val candidates = mutableListOf<Recognition>()
        val numChannels = if (shape.size == 3) shape[1] else 84
        val numBoxes = if (shape.size == 3) shape[2] else 8400
        val numClasses = numChannels - 4

        for (i in 0 until numBoxes) {
            var maxConfidence = 0.0f
            var maxClassId = -1

            for (c in 0 until numClasses) {
                val score = output[(4 + c) * numBoxes + i]
                if (score > maxConfidence) {
                    maxConfidence = score
                    maxClassId = c
                }
            }

            if (maxConfidence >= confidenceThreshold && maxClassId >= 0) {
                val cx = output[0 * numBoxes + i] / inputWidth
                val cy = output[1 * numBoxes + i] / inputHeight
                val w = output[2 * numBoxes + i] / inputWidth
                val h = output[3 * numBoxes + i] / inputHeight

                val left = (cx - w / 2f) * imageWidth
                val top = (cy - h / 2f) * imageHeight
                val right = (cx + w / 2f) * imageWidth
                val bottom = (cy + h / 2f) * imageHeight

                val label = if (maxClassId < labels.size) labels[maxClassId] else "Class $maxClassId"
                val location = RectF(
                    left.coerceIn(0f, imageWidth.toFloat()),
                    top.coerceIn(0f, imageHeight.toFloat()),
                    right.coerceIn(0f, imageWidth.toFloat()),
                    bottom.coerceIn(0f, imageHeight.toFloat())
                )

                candidates.add(Recognition(maxClassId, label, maxConfidence, location))
            }
        }

        return nonMaxSuppression(candidates)
    }

    private fun nonMaxSuppression(boxes: List<Recognition>): List<Recognition> {
        val sorted = boxes.sortedByDescending { it.confidence }.toMutableList()
        val selected = mutableListOf<Recognition>()

        while (sorted.isNotEmpty()) {
            val first = sorted.removeAt(0)
            selected.add(first)

            val iterator = sorted.iterator()
            while (iterator.hasNext()) {
                val next = iterator.next()
                if (calculateIoU(first.location, next.location) >= iouThreshold) {
                    iterator.remove()
                }
            }
        }
        return selected.take(15)
    }

    private fun calculateIoU(a: RectF, b: RectF): Float {
        val intersectionLeft = maxOf(a.left, b.left)
        val intersectionTop = maxOf(a.top, b.top)
        val intersectionRight = minOf(a.right, b.right)
        val intersectionBottom = minOf(a.bottom, b.bottom)

        val intersectionArea = maxOf(0f, intersectionRight - intersectionLeft) *
                maxOf(0f, intersectionBottom - intersectionTop)
        val areaA = (a.right - a.left) * (a.bottom - a.top)
        val areaB = (b.right - b.left) * (b.bottom - b.top)
        val unionArea = areaA + areaB - intersectionArea

        return if (unionArea > 0f) intersectionArea / unionArea else 0f
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}
